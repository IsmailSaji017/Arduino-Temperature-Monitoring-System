#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);

  dht.begin();

  delay(2000);

  Serial.println("Starting...");
}

void loop() {

  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    Serial.println("Failed to read DHT22");
  }
  else {
    Serial.print("Temperature: ");
    Serial.print(t);
    Serial.print(" C  ");

    Serial.print("Humidity: ");
    Serial.print(h);
    Serial.println("%");
  }

  delay(2000);
}

